-- phpMyAdmin SQL Dump
-- version 2.11.6
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Dec 09, 2021 at 09:24 AM
-- Server version: 5.0.51
-- PHP Version: 5.2.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `deals_on_wheels`
--

-- --------------------------------------------------------

--
-- Table structure for table `booking`
--

CREATE TABLE `booking` (
  `b_id` int(100) NOT NULL auto_increment,
  `c_id` int(100) NOT NULL,
  `cr_id` varchar(100) NOT NULL,
  `b_date` varchar(100) NOT NULL,
  `apointment_date` varchar(100) NOT NULL,
  `apointment_time` varchar(100) NOT NULL,
  `status` varchar(100) NOT NULL,
  PRIMARY KEY  (`b_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `booking`
--

INSERT INTO `booking` (`b_id`, `c_id`, `cr_id`, `b_date`, `apointment_date`, `apointment_time`, `status`) VALUES
(1, 1, '1 ', '2021-12-08', '2021-12-10', '22:30', 'Accepted'),
(2, 1, '1 ', '2021-12-08', '2021-12-11', '21:48', 'Rejected'),
(3, 1, '3 ', '2021-12-09', '2021-12-11', '22:55', 'Accepted');

-- --------------------------------------------------------

--
-- Table structure for table `car_details`
--

CREATE TABLE `car_details` (
  `cr_id` int(100) NOT NULL auto_increment,
  `cr_name` varchar(100) NOT NULL,
  `cr_model` varchar(100) NOT NULL,
  `cr_fueltype` varchar(100) NOT NULL,
  `cr_no_of_owners` varchar(100) NOT NULL,
  `cr_photo1` varchar(100) NOT NULL,
  `cr_photo2` varchar(100) NOT NULL,
  `cr_regno` varchar(100) NOT NULL,
  `cr_total_running` varchar(100) NOT NULL,
  `cr_price` varchar(100) NOT NULL,
  `cr_final_price` varchar(100) NOT NULL,
  `cr_status` varchar(100) NOT NULL,
  PRIMARY KEY  (`cr_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `car_details`
--

INSERT INTO `car_details` (`cr_id`, `cr_name`, `cr_model`, `cr_fueltype`, `cr_no_of_owners`, `cr_photo1`, `cr_photo2`, `cr_regno`, `cr_total_running`, `cr_price`, `cr_final_price`, `cr_status`) VALUES
(1, 'maruti', '2018', 'desiel', '1', '5bda92a8-422d-48a9-a844-084090aaeb94-2021-Prius-2020-Edition_001-600x400.jpg', 'honda-city.jpeg', 'KA 49 G 3434', '84000', '650000', '630000', 'Available'),
(2, 'maruti', '2018', 'desiel', '4', '20200123-Sports-Cars-06.jpg', '20200123-Sports-Cars-06.jpg', 'KA 49 G 3434', '49000', '670000', '650000', 'Available'),
(3, 'maruti', '2018', 'desiel', '4', '20200123-Sports-Cars-06.jpg', 'orange-car-hp-right-mercedez.png', 'KA 49 G 3434', '49000', '670000', '650000', 'Available'),
(4, 'maruti', '2018', 'desiel', '3', 'maruti suzuki.jpeg', 'noimg.jpg', 'KA 49 G 3434', '84000', '650000', '630000', 'Available'),
(5, 'van', '2010', 'gas', '4', 'orange-car-hp-right-mercedez.png', '20200123-Sports-Cars-06.jpg', 'ka 09 m 4334', '56000', '190000', '170000', 'Available'),
(6, 'honda', '2019', 'petrol', '1', '20200123-Sports-Cars-06.jpg', 'orange-car-hp-right-mercedez.png', 'ka 49 h 1234', '45000', '230000', '210000', 'Available');

-- --------------------------------------------------------

--
-- Table structure for table `customer_details`
--

CREATE TABLE `customer_details` (
  `c_id` int(100) NOT NULL auto_increment,
  `c_fname` varchar(100) NOT NULL,
  `c_lname` varchar(100) NOT NULL,
  `c_mobile` varchar(100) NOT NULL,
  `c_email` varchar(100) NOT NULL,
  `c_city` varchar(100) NOT NULL,
  `c_photo` varchar(100) NOT NULL,
  PRIMARY KEY  (`c_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `customer_details`
--

INSERT INTO `customer_details` (`c_id`, `c_fname`, `c_lname`, `c_mobile`, `c_email`, `c_city`, `c_photo`) VALUES
(1, 'Baburao', 'Doog', '9663893014', 'babu@gmail.com', 'hukkeri', 'img.jpg'),
(2, 'Baburao', 'Doog', '9741764343', 'doog@gmail.com', 'kotabagi', 'usr.png'),
(3, 'kadappa', 'doog', '9741764342', 'kadappa@gmail.com', 'kotabagi\r\n', 'img2.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE `feedback` (
  `f_id` int(100) NOT NULL auto_increment,
  `f_from` varchar(100) NOT NULL,
  `feedback` varchar(100) NOT NULL,
  `s_date` varchar(100) NOT NULL,
  `status` varchar(100) NOT NULL,
  PRIMARY KEY  (`f_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `feedback`
--

INSERT INTO `feedback` (`f_id`, `f_from`, `feedback`, `s_date`, `status`) VALUES
(1, 'babu@gmail.com', 'Testing ', '2021-12-08', 'New'),
(2, 'kadappa@gmail.com', 'new testing\r\n', '2021-12-09', 'New');

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `utype` varchar(100) NOT NULL,
  `s_question` varchar(100) NOT NULL,
  `s_answer` varchar(100) NOT NULL,
  `status` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`username`, `password`, `utype`, `s_question`, `s_answer`, `status`) VALUES
('admin', '1122', 'admin', 'Which is your Fev.place for travel?', 'paris', 'active'),
('babu@gmail.com', '1122', 'customer', 'Fev, Place for trip?', 'Paris', 'active'),
('doog@gmail.com', '9741764343', 'customer', 'Where did you born?', 'Ghataprabha', 'active'),
('kadappa@gmail.com', '9741764342', 'customer', 'Where did you born?', 'Gataprabha', 'active');

-- --------------------------------------------------------

--
-- Table structure for table `rent_booking`
--

CREATE TABLE `rent_booking` (
  `rb_id` int(100) NOT NULL auto_increment,
  `rc_id` varchar(100) NOT NULL,
  `c_id` varchar(100) NOT NULL,
  `rb_date` varchar(100) NOT NULL,
  `place` varchar(100) NOT NULL,
  `total_km` varchar(100) NOT NULL,
  `total_price` varchar(100) NOT NULL,
  `r_status` varchar(100) NOT NULL,
  PRIMARY KEY  (`rb_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `rent_booking`
--

INSERT INTO `rent_booking` (`rb_id`, `rc_id`, `c_id`, `rb_date`, `place`, `total_km`, `total_price`, `r_status`) VALUES
(1, '3', '1', '2021-12-12', 'Banglore', '850', '8500', 'accepted');

-- --------------------------------------------------------

--
-- Table structure for table `rent_cars`
--

CREATE TABLE `rent_cars` (
  `rc_id` int(100) NOT NULL auto_increment,
  `car_name` varchar(100) NOT NULL,
  `car_type` varchar(100) NOT NULL,
  `car_number` varchar(100) NOT NULL,
  `car_photo` varchar(100) NOT NULL,
  `car_owner` varchar(100) NOT NULL,
  `car_status` varchar(100) NOT NULL,
  `car_kmprice` varchar(100) NOT NULL,
  PRIMARY KEY  (`rc_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `rent_cars`
--

INSERT INTO `rent_cars` (`rc_id`, `car_name`, `car_type`, `car_number`, `car_photo`, `car_owner`, `car_status`, `car_kmprice`) VALUES
(1, 'Swift', 'Car', 'KA23X1234', '1637819842707935427849741216320.jpg', 'Babu', 'Available', '10'),
(2, 'maruti', 'ertiga', 'KA 49 G 3434', 'orange-car-hp-right-mercedez.png', 'baburao', 'Available', '12'),
(3, 'Swift', 'Car', 'KA 49 G 3434', '7cfeb624e868f121e200f225ae07beb92817f476.jpg', 'baburao', 'Available', '10');
